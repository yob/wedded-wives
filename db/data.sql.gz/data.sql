--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.unique_schema_migrations;
DROP INDEX public.index_gifts_on_suggestion_id;
ALTER TABLE ONLY public.suggestions DROP CONSTRAINT suggestions_pkey;
ALTER TABLE ONLY public.gifts DROP CONSTRAINT gifts_pkey;
ALTER TABLE public.suggestions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gifts ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.suggestions_id_seq;
DROP TABLE public.suggestions;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.gifts_id_seq;
DROP TABLE public.gifts;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
DROP DATABASE weddedwives;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: jh
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO jh;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: jh
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: gifts; Type: TABLE; Schema: public; Owner: jh; Tablespace: 
--

CREATE TABLE gifts (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    email character varying(128) NOT NULL,
    suggestion_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.gifts OWNER TO jh;

--
-- Name: gifts_id_seq; Type: SEQUENCE; Schema: public; Owner: jh
--

CREATE SEQUENCE gifts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gifts_id_seq OWNER TO jh;

--
-- Name: gifts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jh
--

ALTER SEQUENCE gifts_id_seq OWNED BY gifts.id;


--
-- Name: gifts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jh
--

SELECT pg_catalog.setval('gifts_id_seq', 42, true);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: jh; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO jh;

--
-- Name: suggestions; Type: TABLE; Schema: public; Owner: jh; Tablespace: 
--

CREATE TABLE suggestions (
    id integer NOT NULL,
    description character varying(255) NOT NULL,
    count integer NOT NULL,
    value numeric(8,2) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.suggestions OWNER TO jh;

--
-- Name: suggestions_id_seq; Type: SEQUENCE; Schema: public; Owner: jh
--

CREATE SEQUENCE suggestions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.suggestions_id_seq OWNER TO jh;

--
-- Name: suggestions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jh
--

ALTER SEQUENCE suggestions_id_seq OWNED BY suggestions.id;


--
-- Name: suggestions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jh
--

SELECT pg_catalog.setval('suggestions_id_seq', 19, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: jh
--

ALTER TABLE ONLY gifts ALTER COLUMN id SET DEFAULT nextval('gifts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: jh
--

ALTER TABLE ONLY suggestions ALTER COLUMN id SET DEFAULT nextval('suggestions_id_seq'::regclass);


--
-- Data for Name: gifts; Type: TABLE DATA; Schema: public; Owner: jh
--

COPY gifts (id, name, email, suggestion_id, created_at, updated_at) FROM stdin;
7	Sammy	sammy_ray32@hotmail.com	8	2011-02-08 13:06:37.006135	2011-02-08 13:06:37.006135
8	green.maree@gmail.com	maree&gary	5	2011-02-09 03:54:59.196153	2011-02-09 03:54:59.196153
9	Jess Joss	jestosterone@hotmail.com	2	2011-02-18 01:54:54.386154	2011-02-18 01:54:54.386154
10	Jess & Jay	jessicamallan@hotmail.com	14	2011-02-18 06:57:50.489975	2011-02-18 06:57:50.489975
11	Kristy and Jess	harris_k_d@hotmail.com	3	2011-02-20 03:31:58.622253	2011-02-20 03:31:58.622253
12	Kristy and Jess	harris_k_d@hotmail.com	17	2011-02-20 03:33:07.250464	2011-02-20 03:33:07.250464
13	Helen Lilley	helenlilley@gmail.com	11	2011-03-03 07:26:43.155338	2011-03-03 07:26:43.155338
14	Jess Joss	jestosterone@hotmail.com	6	2011-03-07 02:48:32.715507	2011-03-07 02:48:32.715507
15	Sharon Dale :)	skyezak@internode.on.net	9	2011-03-09 21:56:39.787707	2011-03-09 21:56:39.787707
16	Sharon Dale :)	skyezak@internode.on.net	16	2011-03-09 21:57:02.881916	2011-03-09 21:57:02.881916
17	David Armstrong	macrostheblonde@gmail.com	16	2011-03-13 22:32:04.00447	2011-03-13 22:32:04.00447
18	Bernadette Murphy	wingsparkle@hotmail.com	16	2011-03-13 22:32:31.545032	2011-03-13 22:32:31.545032
19	Madeleine, Joe and Henry	madeleinelhealy@yahoo.com	10	2011-03-14 03:52:47.003775	2011-03-14 03:52:47.003775
20	Danielle Coric	daniiontheroad@three.com.au	1	2011-03-14 17:43:28.454907	2011-03-14 17:43:28.454907
21	Ash Starr	optimistically_pessimistic_19@hotmail.com	3	2011-03-15 22:35:23.446612	2011-03-15 22:35:23.446612
22	Ash Starr	optimistically_pessimistic_19@hotmail.com	3	2011-03-15 22:39:36.593022	2011-03-15 22:39:36.593022
23	Ash Starr	optimistically_pessimistic_19@hotmail.com	3	2011-03-15 22:40:09.202085	2011-03-15 22:40:09.202085
24	Yvonne & Hugh Anthony	yvonne.anthony@bp.com	7	2011-03-16 23:20:31.477961	2011-03-16 23:20:31.477961
25	Yvonne & Hugh Anthony	yvonne.anthony@bp.com	7	2011-03-16 23:20:45.647399	2011-03-16 23:20:45.647399
26	Sharyn & David Anthony	yvonne.anthony@bp.com	11	2011-03-16 23:23:29.255013	2011-03-16 23:23:29.255013
27	Andrew Anthony	yvonne.anthony@bp.com	18	2011-03-16 23:24:47.196833	2011-03-16 23:24:47.196833
28	Yeti	jamesyette@hotmail.com	16	2011-03-18 05:24:11.8495	2011-03-18 05:24:11.8495
29	Sarah, Steve, Jade & Casper	santilli.steven.j@edumail.vic.gov.au	9	2011-03-18 10:31:05.865742	2011-03-18 10:31:05.865742
30	Polly Morgan	polly.morgan@gmail.com	1	2011-03-18 11:10:15.932986	2011-03-18 11:10:15.932986
31	Kristyn Crehan + Andrew Martin	a.a.d.martin@gmail.com	15	2011-03-18 22:51:40.893817	2011-03-18 22:51:40.893817
32	Andrea Foxworthy	angefoxy@yahoo.com.au	16	2011-03-18 23:24:49.254104	2011-03-18 23:24:49.254104
33	Amy & Tim	amy_lester@hotmail.com	19	2011-03-19 00:22:27.176662	2011-03-19 00:22:27.176662
34	Blue Mahy	bluejaryn@yahoo.com.au	9	2011-03-19 00:24:26.858143	2011-03-19 00:24:26.858143
35	Amy & Tim	amy	19	2011-03-19 00:28:02.360092	2011-03-19 00:28:02.360092
36	Kara and Daniel	kara_sheehan@hotmail.com	11	2011-03-19 01:05:23.990961	2011-03-19 01:05:23.990961
37	Stu and Bek	bekki_p@hotmail.com	16	2011-03-19 02:17:30.224121	2011-03-19 02:17:30.224121
38	Dennis 	djjarvis@live.com	4	2011-03-23 08:58:28.205529	2011-03-23 08:58:28.205529
39	Ani & Euan Kelso	ani_the_nanny@yahoo.com.au	11	2011-03-29 17:13:12.858928	2011-03-29 17:13:12.858928
40	Terry Healy	Rosannah.Healy@gmail.com	9	2011-03-31 03:49:52.637259	2011-03-31 03:49:52.637259
41	Terry Healy	Rosannah.Healy@gmail.com	11	2011-04-04 05:04:50.787659	2011-04-04 05:04:50.787659
42	Terry Healy	Rosannah.Healy@gmail.com	11	2011-04-04 05:05:19.785388	2011-04-04 05:05:19.785388
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: jh
--

COPY schema_migrations (version) FROM stdin;
20110116041058
20110116123352
\.


--
-- Data for Name: suggestions; Type: TABLE DATA; Schema: public; Owner: jh
--

COPY suggestions (id, description, count, value, created_at, updated_at) FROM stdin;
1	VIP tour of Graceland for two	2	70.00	2011-01-17 12:58:44.095746	2011-01-17 12:58:44.095746
2	Alcohol allowance to help Jess survive Graceland	1	30.00	2011-01-17 12:59:08.587299	2011-01-17 12:59:08.587299
6	Snacks on the plane allowance	1	20.00	2011-01-26 13:08:43.6678	2011-01-26 13:08:43.6678
3	Horse-drawn carriage rides, Stanley Park Vancouver	3	30.00	2011-01-17 12:59:41.247239	2011-01-26 13:09:27.765959
4	Easter Sunday Greyhound Bus ride to Banff	2	81.00	2011-01-17 13:00:51.694185	2011-01-26 13:10:39.751516
5	Easter egg allowance for the bus ride	1	20.00	2011-01-17 13:01:31.807073	2011-01-26 13:11:12.488201
7	Icefields Parkway glacier tour	2	151.00	2011-01-26 13:11:57.95606	2011-01-26 13:11:57.95606
8	Thermals so Charlie will agree to the glacier	1	50.00	2011-01-26 13:12:22.415966	2011-01-26 13:12:22.415966
9	Contribution toward our Canadian celebrant hire fee	4	50.00	2011-01-26 13:13:11.685916	2011-01-26 13:13:11.685916
10	Post wedding ceremony dinner with the parentals	1	100.00	2011-01-26 13:13:37.041962	2011-01-26 13:13:37.041962
11	Contribution toward our luxury wedding night suite	7	100.00	2011-01-26 13:14:02.59602	2011-01-26 13:14:02.59602
12	Contribution toward a chauffered silver bentley tour of the Rockies	7	75.00	2011-01-26 13:14:58.242381	2011-01-26 13:14:58.242381
13	Backpacker tour between Banff and Vancouver	2	200.00	2011-01-26 13:15:24.936035	2011-01-26 13:15:24.936035
14	Night out in the lesbian bars of San Francisco	1	50.00	2011-01-26 13:15:52.175218	2011-01-26 13:15:52.175218
15	Two nights at a San Francisco backpackers	1	120.00	2011-01-26 13:16:14.03589	2011-01-26 13:16:14.03589
16	Contribution toward our Disneyland tickets	6	50.00	2011-01-26 13:16:50.784717	2011-01-26 13:16:50.784717
17	Ridiculous Disney character hat allowance	1	40.00	2011-01-26 13:17:24.67226	2011-01-26 13:17:24.67226
18	Photos they take as you scream on rides allowance	1	40.00	2011-01-26 13:17:43.756221	2011-01-26 13:17:43.756221
19	Disneyland soreness-fixing massages	2	80.00	2011-01-26 13:18:12.521099	2011-01-26 13:18:12.521099
\.


--
-- Name: gifts_pkey; Type: CONSTRAINT; Schema: public; Owner: jh; Tablespace: 
--

ALTER TABLE ONLY gifts
    ADD CONSTRAINT gifts_pkey PRIMARY KEY (id);


--
-- Name: suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: jh; Tablespace: 
--

ALTER TABLE ONLY suggestions
    ADD CONSTRAINT suggestions_pkey PRIMARY KEY (id);


--
-- Name: index_gifts_on_suggestion_id; Type: INDEX; Schema: public; Owner: jh; Tablespace: 
--

CREATE INDEX index_gifts_on_suggestion_id ON gifts USING btree (suggestion_id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: jh; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- PostgreSQL database dump complete
--

